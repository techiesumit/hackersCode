package com.example.spring.validator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
